#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "bmp.h"


byte ** alloc_2d_array(int num_rows, int num_cols)
{
	int i = 0;
	byte **img_data = (byte **)malloc(sizeof(byte *)*num_rows);
	for(i;i<num_rows;i++)
		*(img_data+i) = (byte *)malloc(sizeof(byte)*num_cols);

	return img_data;
}



void free_2d_array(byte **a, int num_rows)
{
	int i = 0;
	for(i;i<num_rows;i++)
		free(*(a+i));

	free(a);
}



bmp_image * bmp_image_read(char *filename)
{
	bmp_image *i =(bmp_image *)malloc(sizeof(bmp_image));

	FILE *file = fopen(filename,"rb");

	byte *header = (byte *)malloc(sizeof(byte)*54);

	fread(header,1,54,file);

	if(*header!='B' || *(header+1)!='M')
	{
		fclose(file);
		return NULL;
	}

	i->width = (*(header+18) | (*(header+19)<<8) | (*(header+20)<<16) | (*(header+21)<<24));

	i->height = (*(header+22) | (*(header+23)<<8) | (*(header+24)<<16) | (*(header+25)<<24));


	int padding = (4 - (3 * i->width) % 4) % 4;		//why do I need the extra % 4?
	int num_pixels = i->width * i->height;
	int num_bytes = 3 * num_pixels + padding * i->height;
	int hdr_num_bytes = *(header+2) | (*(header+3)<<8) | (*(header+4)<<16) | (*(header+5)<<24);


	char *bytes = (char *)malloc(sizeof(char)*num_bytes);

	fread(bytes,1,num_bytes,file);

	fclose(file);

	i->red = alloc_2d_array(i->height,i->width);
	i->green = alloc_2d_array(i->height,i->width);
	i->blue = alloc_2d_array(i->height,i->width); 

	int bindex = 0;
	int row = i->height - 1;
	int col = 0;
	for(row;row>=0;row--)
	{
		col = 0;
		for(col;col<=i->width-1;col++)
		{
			i->blue[row][col] = bytes[bindex++];
			i->green[row][col] = bytes[bindex++];
			i->red[row][col] = bytes[bindex++];
		}
		bindex += padding;
	}

	return i;
}





void bmp_image_write(bmp_image *i, char *filename)
{
	FILE *file = fopen(filename,"wb");

	byte *hdr = (byte*)malloc(sizeof(byte)*54);

	*hdr = 'B';
	*(hdr+1) = 'M';

	int padding = (4 - (3*i->width) % 4) %4;		//you were right it was the padding that was the problem . . I forgot to multiply width by 3

	int image_file_size = i->width * i->height * 3 + padding*i->height + 54;

	/*printf("image file size: %d\n",image_file_size);	*/

	*(hdr+2) = image_file_size;
	*(hdr+3) = image_file_size >> 8;
	*(hdr+4) = image_file_size >> 16;
	*(hdr+5) = image_file_size >> 24;
	
	*(hdr+6) = 0;		//6-9 always 0
	*(hdr+7) = 0;
	*(hdr+8) = 0;
	*(hdr+9) = 0;

	*(hdr+10) = 54;		//10 - 13 offset (54)
	*(hdr+11) = 0;
	*(hdr+12) = 0;
	*(hdr+13) = 0;

	*(hdr+14) = 40;		//size of BITMAPINFOHEADER
	*(hdr+15) = 0;	
	*(hdr+16) = 0;
	*(hdr+17) = 0;

	*(hdr+18) = i->width;			//write width and height
	*(hdr+19) = i->width >> 8;
	*(hdr+20) = i->width >> 16;
	*(hdr+21) = i->width >> 24;

	*(hdr+22) = i->height;
	*(hdr+23) = i->height >> 8;
	*(hdr+24) = i->height >> 16;
	*(hdr+25) = i->height >> 24;

	*(hdr+26) = 1;		//number of bitplanes = 1
	*(hdr+27) = 0;

	*(hdr+28) = 24;		//number of bits per pixel
	*(hdr+29) = 0;
	
	int y = 30;
	for(y;y<54;y++) *(hdr+y) = 0;

	fwrite(hdr,1,54,file);

	fflush(file);
	int row = i->height - 1;
	int col = 0;
	int j = 0;
	byte *buffer = (char *)malloc(sizeof(char)*1);
	*buffer = 0;
	

	for(row;row>=0;row--)
	{
		col = 0;
		for(col;col<=i->width-1;col++)
		{
			fwrite((*(i->blue+row)+col),1,1,file);
			fwrite((*(i->green+row)+col),1,1,file);
			fwrite((*(i->red+row)+col),1,1,file);
		}
		j=0;
		for(j;j<padding;j++) fwrite(buffer,1,1,file);
	}
	fclose(file);

}




void bmp_change_intensity(bmp_image *img, double multiplier)
{
	int row = 0;
	int col = 0;
	double temp;

	for(row;row<img->height;row++)
	{
		col = 0;
		for(col;col<img->width;col++)
		{
			temp = *(*(img->blue+row)+col) * multiplier;
			if(temp>=255) *(*(img->blue+row)+col) = 255;
			else *(*(img->blue+row)+col) = floor(temp);

			temp = *(*(img->green+row)+col) * multiplier;
			if(temp>=255) *(*(img->green+row)+col) = 255;
			else *(*(img->green+row)+col) = floor(temp);

			temp = *(*(img->red+row)+col) * multiplier;
			if(temp>=255) *(*(img->red+row)+col) = 255;
			else *(*(img->red+row)+col) = floor(temp);
		}
	}
}


void bmp_flip_horizontal(bmp_image *img)
{
	int middle = floor(img->height/2);
	byte temp;

	int row = 0;
	int col = 0;
	int a;

	for(row;row<middle;row++)
	{
		col = 0;
		a = (img->height - 1) - row;
		for(col;col<img->width;col++)
		{
			temp = *(*(img->blue+row)+col);
			*(*(img->blue+row)+col) = *(*(img->blue+a)+col);
			*(*(img->blue+a)+col) = temp;

			temp = *(*(img->green+row)+col);
			*(*(img->green+row)+col) = *(*(img->green+a)+col);
			*(*(img->green+a)+col) = temp;

			temp = *(*(img->red+row)+col);
			*(*(img->red+row)+col) = *(*(img->red+a)+col);
			*(*(img->red+a)+col) = temp;
		}
	}

}


void bmp_flip_vertical(bmp_image *img)
{
	int middle = floor(img->width/2);
	byte temp;

	int row = 0;
	int col = 0;
	int a;

	for(col;col<middle;col++)
	{
		row = 0;
		a = (img->width - 1) - col;
		for(row;row<img->height;row++)
		{
			temp = *(*(img->blue+row)+col);
			*(*(img->blue+row)+col) = *(*(img->blue+row)+a);
			*(*(img->blue+row)+a) = temp;

			temp = *(*(img->green+row)+col);
			*(*(img->green+row)+col) = *(*(img->green+row)+a);
			*(*(img->green+row)+a) = temp;

			temp = *(*(img->red+row)+col);
			*(*(img->red+row)+col) = *(*(img->red+row)+a);
			*(*(img->red+row)+a) = temp;
		}
	}
}





void bmp_rotate_clockwise(bmp_image *img)
{

	int row = 0;
	int col = 0;
	int temp,temp2;		

	byte **tempred = alloc_2d_array(img->width,img->height);
	byte **tempblue = alloc_2d_array(img->width,img->height);
	byte **tempgreen = alloc_2d_array(img->width,img->height);

	for(row;row<img->height;row++)
	{
		col = 0;
		temp = img->height-1-row;
		for(col;col<img->width;col++)
		{
			//tempred[col][temp] = img->red[row][col];
			//tempblue[col][temp] = img->blue[row][col];
			//tempgreen[col][temp] = img->green[row][col];


			*(*(tempred+col)+temp) = *( *(img->red+row)+col);
			*(*(tempblue+col)+temp) = *( *(img->blue+row)+col);	
			*(*(tempgreen+col)+temp) = *( *(img->green+row)+col);
		}
	}
	

	free_2d_array(img->red,img->height);
	free_2d_array(img->blue,img->height);
	free_2d_array(img->green,img->height);

	img->blue = tempblue;
	img->red = tempred;
	img->green = tempgreen;



	temp = img->height;
	img->height = img->width;
	img->width = temp;
}

void bmp_rotate_counter_clockwise(bmp_image *img)
{
	
	int row = 0;
	int col = 0;
	int temp,temp2;		

	byte **tempred = alloc_2d_array(img->width,img->height);
	byte **tempblue = alloc_2d_array(img->width,img->height);
	byte **tempgreen = alloc_2d_array(img->width,img->height);

	for(row;row<img->height;row++)
	{
		col = 0;
		for(col;col<img->width;col++)
		{
			//tempred[col][temp] = img->red[row][col];
			//tempblue[col][temp] = img->blue[row][col];
			//tempgreen[col][temp] = img->green[row][col];
			temp = (img->width-1) - col;

			*(*(tempred+temp)+row) = *( *(img->red+row)+col);
			*(*(tempblue+temp)+row) = *( *(img->blue+row)+col);	
			*(*(tempgreen+temp)+row) = *( *(img->green+row)+col);
		}
	}
	

	free_2d_array(img->red,img->height);
	free_2d_array(img->blue,img->height);
	free_2d_array(img->green,img->height);

	img->blue = tempblue;
	img->red = tempred;
	img->green = tempgreen;



	temp = img->height;
	img->height = img->width;
	img->width = temp;
}


void bmp_invert(bmp_image *img)
{
	int row = 0,col = 0;

	for(row;row<img->height;row++)
	{
		col = 0;
		for(col;col<img->width;col++)
		{
			*(*(img->red+row)+col) = 255 - *(*(img->red+row)+col);
			*(*(img->blue+row)+col) = 255 - *(*(img->blue+row)+col);
			*(*(img->green+row)+col) = 255 - *(*(img->green+row)+col);
		}
	}
}	

byte box_average(int x,int y, bmp_image *img, int color)		//x is row y is col
{
	byte temp;
	if(x==0)
	{
		if(y==0)
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x+1][y] + img->red[x][y+1] + img->red[x+1][y+1])/4);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x+1][y] + img->blue[x][y+1] + img->blue[x+1][y+1])/4);

			else
				temp = (byte)((img->green[x][y] + img->green[x+1][y] + img->green[x][y+1] + img->green[x+1][y+1])/4);
		}
		else if(y==img->width-1)
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x+1][y] + img->red[x][y-1] + img->red[x+1][y-1])/4);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x+1][y] + img->blue[x][y-1] + img->blue[x+1][y-1])/4);

			else
				temp = (byte)((img->green[x][y] + img->green[x+1][y] + img->green[x][y-1] + img->green[x+1][y-1])/4);
		}
		else
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x][y-1] + img->red[x][y+1] + img->red[x+1][y-1] + img->red[x+1][y] + img->red[x+1][y+1])/6);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x][y-1] + img->blue[x][y+1] + img->blue[x+1][y-1] + img->blue[x+1][y] + img->blue[x+1][y+1])/6);

			else
				temp = (byte)((img->green[x][y] + img->green[x][y-1] + img->green[x][y+1] + img->green[x+1][y-1] + img->green[x+1][y] + img->green[x+1][y+1])/6);
		}
	}
	else if(x==img->height-1)
	{
		if(y==0)
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x-1][y] + img->red[x][y+1] + img->red[x-1][y+1])/4);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x-1][y] + img->blue[x][y+1] + img->blue[x-1][y+1])/4);

			else
				temp = (byte)((img->green[x][y] + img->green[x-1][y] + img->green[x][y+1] + img->green[x-1][y+1])/4);
		}
		else if(y==img->width-1)
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x-1][y] + img->red[x][y-1] + img->red[x-1][y-1])/4);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x-1][y] + img->blue[x][y-1] + img->blue[x-1][y-1])/4);

			else
				temp = (byte)((img->green[x][y] + img->green[x-1][y] + img->green[x][y-1] + img->green[x-1][y-1])/4);
		}
		else
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x][y-1] + img->red[x][y+1] + img->red[x-1][y-1] + img->red[x-1][y] + img->red[x-1][y+1])/6);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x][y-1] + img->blue[x][y+1] + img->blue[x-1][y-1] + img->blue[x-1][y] + img->blue[x-1][y+1])/6);

			else
				temp = (byte)((img->green[x][y] + img->green[x][y-1] + img->green[x][y+1] + img->green[x-1][y-1] + img->green[x-1][y] + img->green[x-1][y+1])/6);
		}
	}
	else
	{
		if(y==0)
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x-1][y] + img->red[x+1][y] + img->red[x-1][y+1] + img->red[x][y+1] + img->red[x+1][y+1])/6);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x-1][y] + img->blue[x+1][y] + img->blue[x-1][y+1] + img->blue[x][y+1] + img->blue[x+1][y+1])/6);

			else
				temp = (byte)((img->green[x][y] + img->green[x-1][y] + img->green[x+1][y] + img->green[x-1][y+1] + img->green[x][y+1] + img->green[x+1][y+1])/6);
		}
		else if(y==img->width-1)
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x-1][y] + img->red[x+1][y] + img->red[x-1][y-1] + img->red[x][y-1] + img->red[x+1][y-1])/6);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x-1][y] + img->blue[x+1][y] + img->blue[x-1][y-1] + img->blue[x][y-1] + img->blue[x+1][y-1])/6);

			else
				temp = (byte)((img->green[x][y] + img->green[x-1][y] + img->green[x+1][y] + img->green[x-1][y-1] + img->green[x][y-1] + img->green[x+1][y-1])/6);
		}
		else
		{
			if(color==0)
				temp = (byte)((img->red[x][y] + img->red[x-1][y] + img->red[x+1][y] + img->red[x-1][y-1] + img->red[x][y-1] + img->red[x+1][y-1] + img->red[x-1][y+1] + img->red[x][y+1] + img->red[x+1][y+1])/9);

			else if(color==1)
				temp = (byte)((img->blue[x][y] + img->blue[x-1][y] + img->blue[x+1][y] + img->blue[x-1][y-1] + img->blue[x][y-1] + img->blue[x+1][y-1] + img->blue[x-1][y+1] + img->blue[x][y+1] + img->blue[x+1][y+1])/9);

			else
				temp = (byte)((img->green[x][y] + img->green[x-1][y] + img->green[x+1][y] + img->green[x-1][y-1] + img->green[x][y-1] + img->green[x+1][y-1] + img->green[x-1][y+1] + img->green[x][y+1] + img->green[x+1][y+1])/9);
		}
	}

	return temp;
}			





			
			

void bmp_blur(bmp_image *img)
{
	int row = 0,col = 0;

	byte **tempred = alloc_2d_array(img->height,img->width);
	byte **tempblue = alloc_2d_array(img->height,img->width);
	byte **tempgreen = alloc_2d_array(img->height,img->width);


	for(row;row<img->height;row++)
	{
		col = 0;
		for(col;col<img->width;col++)
		{
			*(*(tempred+row)+col) = box_average(row,col,img,0);
			*(*(tempblue+row)+col) = box_average(row,col,img,1);
			*(*(tempgreen+row)+col) = box_average(row,col,img,2);
		}
	}

	free_2d_array(img->red,img->height);
	free_2d_array(img->blue,img->height);
	free_2d_array(img->green,img->height);


	img->red = tempred;
	img->blue = tempblue;
	img->green = tempgreen;
	
}

void bmp_enlarge(bmp_image *img)
{
	byte **tempred = alloc_2d_array(img->height*2,img->width*2);
	byte **tempblue = alloc_2d_array(img->height*2,img->width*2);
	byte **tempgreen = alloc_2d_array(img->height*2,img->width*2);

	int row = 0,col = 0;

	for(row;row<img->height;row++)
	{
		col = 0;
		for(col;col<img->width;col++)
		{
			tempred[row*2][col*2] = img->red[row][col];
			tempred[row*2+1][col*2] = img->red[row][col];
			tempred[row*2][col*2+1] = img->red[row][col];
			tempred[row*2+1][col*2+1] = img->red[row][col];

			tempblue[row*2][col*2] = img->blue[row][col];
			tempblue[row*2+1][col*2] = img->blue[row][col];
			tempblue[row*2][col*2+1] = img->blue[row][col];
			tempblue[row*2+1][col*2+1] = img->blue[row][col];

			tempgreen[row*2][col*2] = img->green[row][col];
			tempgreen[row*2+1][col*2] = img->green[row][col];
			tempgreen[row*2][col*2+1] = img->green[row][col];
			tempgreen[row*2+1][col*2+1] = img->green[row][col];

		}
	}

	free_2d_array(img->red,img->height);
	free_2d_array(img->blue,img->height);
	free_2d_array(img->green,img->height);

	img->red = tempred;
	img->blue = tempblue;
	img->green = tempgreen;

	img->width = 2*img->width;
	img->height = 2*img->height;

}



void bmp_shrink(bmp_image *img)
{
	byte **tempred = alloc_2d_array(img->height/2,img->width/2);
	byte **tempblue = alloc_2d_array(img->height/2,img->width/2);
	byte **tempgreen = alloc_2d_array(img->height/2,img->width/2);

	int row = 0,col = 0;

	for(row;row<img->height-1;row+=2)
	{
		col = 0;
		for(col;col<img->width-1;col+=2)
		{
			tempred[row/2][col/2] = img->red[row][col];
			tempblue[row/2][col/2] = img->blue[row][col];
			tempgreen[row/2][col/2] = img->green[row][col];
		}
	}


	img->width = img->width/2;
	img->height = img->height/2;

	free_2d_array(img->red,img->height);
	free_2d_array(img->blue,img->height);
	free_2d_array(img->green,img->height);

	img->red = tempred;
	img->blue = tempblue;
	img->green = tempgreen;


}

void bmp_grayscale(bmp_image *img)
{
	int row = 0, col = 0;
	double grayval;

	for(row;row<img->height;row++)
	{
		col = 0;
		for(col;col<img->width;col++)
		{
			grayval = 0.3*img->red[row][col] + 0.59*img->green[row][col] + 0.11*img->blue[row][col];
			img->red[row][col] = (byte) grayval;
			img->blue[row][col] = (byte) grayval;
			img->green[row][col] = (byte) grayval;
		}
	}
}


void bmp_color(bmp_image *img, double red,double blue,double green)
{
	int row=0,col=0;

	for(row;row<img->height;row++)
	{
		col=0;
		for(col;col<img->width;col++)
		{
			img->red[row][col] = (red*img->red[row][col]>255) ? 255 : red*img->red[row][col];
			img->blue[row][col] = (blue*img->blue[row][col]>255) ? 255 : blue*img->blue[row][col];
			img->green[row][col] = (green*img->green[row][col]>255) ? 255 : green*img->green[row][col];
		}
	}

}


















