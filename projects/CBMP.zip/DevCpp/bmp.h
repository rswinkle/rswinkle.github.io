#ifndef BMP_H
#define BMP_H


typedef unsigned char byte;

typedef struct
{
	int height;
	int width;
	byte **red;
	byte **green;
	byte **blue;
}bmp_image;


byte ** alloc_2d_array(int num_rows, int num_cols);

void free_2d_array(byte **a, int num_rows);

bmp_image * bmp_image_read(char *filename);

void bmp_image_write(bmp_image *i, char *filename);

void bmp_change_intensity(bmp_image *img, double multiplier);

void bmp_flip_horizontal(bmp_image *img);

void bmp_flip_vertical(bmp_image *img);

void bmp_rotate_clockwise(bmp_image *img);

void bmp_rotate_counter_clockwise(bmp_image *img);

void bmp_invert(bmp_image *img);

void bmp_blur(bmp_image *img);

byte box_average(int x,int y,bmp_image *img, int color);

void bmp_enlarge(bmp_image *img);

void bmp_shrink(bmp_image *img);

void bmp_grayscale(bmp_image *img);

void bmp_color(bmp_image *img, double red,double blue,double green);
#endif
