#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"



void printmenu();




int main()
{
	char choice;
	char file[30];	
	double mult, red, blue,green;
	bmp_image *image;

	do
	{
		printmenu();

		do{ choice = getchar();}while(choice=='\n');



		switch(choice)
		{
			case '1':
				printf("\nEnter an image to read: ");
				scanf("%s",file);
				getchar();
				image = bmp_image_read(file);
				printf("\nImage read.\n");
				break;

			case '2':
				printf("\nEnter a file name to write to: ");
				scanf("%s",file);
				bmp_image_write(image,file);
				printf("\nImage written.\n");
				break;

			case '3':
				printf("\nEnter an intensity multiplier (1 = no change): ");
				scanf("%lf",&mult);
				bmp_change_intensity(image,mult);
				printf("\nImage modified.\n");
				break;

			case '4':
				bmp_flip_horizontal(image);
				printf("\nImage flipped horizontally.\n");
				break;

			case '5':
				bmp_flip_vertical(image);
				printf("\nImage flipped vertically.\n");
				break;

			case '6':
				bmp_rotate_clockwise(image);
				printf("\nImage rotated 90 degrees clockwise.\n");
				break;

			case '7':
				bmp_rotate_counter_clockwise(image);
				printf("\nImage rotated 90 degrees counter clockwise.\n");
				break;

			case '8':
				bmp_invert(image);
				printf("\nImage inverted.\n");
				break;

			case '9':
				bmp_blur(image);
				printf("\nImage blurred.\n");
				break;


			case 'A':
			case 'a':
				bmp_enlarge(image);
				printf("\nImage size doubled.\n");
				break;

			case 'B':
			case 'b':
				bmp_shrink(image);
				printf("\nImage size halved.\n");
				break;

			case 'C':
			case 'c':
				bmp_grayscale(image);
				printf("\nImage converted to grayscale\n");
				break;

			case 'D':
			case 'd':
				printf("\nEnter a multipler for each color(1 for each is no change, the same for each is just darker or lighter same as changing intensity.");
				printf("\nEnter a multiplier for red:");
				scanf("%lf",&red);
				printf("\nEnter a multiplier for blue:");
				scanf("%lf",&blue);
				printf("\nEnter a multiplier for green:");
				scanf("%lf",&green);
				bmp_color(image,red,blue,green);
				printf("\nColor adjusted.\n");
				break;

			case 'Q':
			case 'q':
				printf("\nExiting.\n");
				break;

			default:
				printf("\nInvalid choice\n");

		}

	}while(choice!='Q' && choice!='q');





	return 0;
}






void printmenu()
{
	printf("\nBMP Image Processing Program\n");
	printf("----------------------------\n");
	printf("1. Read Image\n");
	printf("2. Write Image\n");
	printf("3. Change Intensity\n");
	printf("4. Flip Horizontal\n");
	printf("5. Flip Vertical\n");
	printf("6. Rotate Clockwise\n");
	printf("7. Rotate Counter-Clockwise\n");
	printf("8. Invert Image\n");
	printf("9. Blur Image\n");
	printf("A. Enlarge Image\n");
	printf("B. Shrink Image\n");
	printf("C. Convert to grayscale\n");
	printf("D. Adjust color\n");
	printf("Q. Quit\n\n");
	printf("Choice?");
}
