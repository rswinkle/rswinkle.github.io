//Written by Robert Winkler
//www.robertwinkler.com

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mystack.h"



struct mystack
{
	char *data;
	struct mystack *next;
};

typedef struct mystack stack;

stack *top = NULL;

int size = 0;

void stack_init()
{
	top = NULL;
	size = 0;
}

void display_stack()
{
	if(top==NULL) printf("Stack empty.\n");
	else
	{
		int i = 0;
		printf("top: %s\n",top->data);
		stack *temp = top->next;
		for(i;;i++)
		{
			if(temp!=NULL)
			{
				printf("%d: %s\n",i,temp->data);
				temp = temp->next;
			}
			else break;
		}
	}
}

char * stack_top()
{
	if(top!=NULL) return top->data;
	else return NULL;
}

char * pop()
{
	if(top==NULL) return NULL;
	else
	{
		char *str = top->data;
		stack *temp = top;
		top = top->next;
		//free(temp->data);			//This is a small memory leak except for the custom attributes where I use
		free(temp);					//the return value and I want it to point at a valid allocated string
									
		size--;					
	
		return str;
	}
}

void push(char *next)
{
	stack *temp = (stack*)malloc(sizeof(stack));
	temp->data = next;
		
	temp->next = top;
	top = temp;

	size++;
}

int stack_size() { return size; }

int stack_empty()
{
	if(top==NULL) return 1;
	else return 0;
}
