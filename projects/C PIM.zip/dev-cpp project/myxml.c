//Written by Robert Winkler
//www.robertwinkler.com

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Contact.h"
#include "functions.h"
#include "myxml.h"
#include "mystack.h"




void loadContacts()
{
	char *filename = NULL;		//set up/initialize variables;

	char temp = '0';

	char *buffer;
	char roots[20];
	int check = 0;

	struct Contact *newcontact = NULL;		//initialize temp variable

	stack_init();				//initialize stack;	

	printf("Please enter a file name to load contacts from:");
	filename = readstring(30,1);
	
	FILE *data = fopen(filename,"r");
	
	if(data==NULL) 
	{
		printf("Error in opening/reading file\n");
		free(filename);
		return;
	}

	if(!testRoot(data))
	{
		fclose(data); 
		return;
	}
	
	for(;;)
	{
		check = testTag(data);
		if(check==1)
		{
			newcontact = getContact(data);
			if(newcontact==NULL)							//create contact if error close file and return
			{
				fclose(data);
				return;
			}
			else Contacts(0,newcontact);
		}
		else if(check==0)					//if found end tag </contacts> close file and return
		{
			fclose(data);
			printf("Contacts loaded successfully.\n");
			return;
		}
		else if(check==-1)						//error was found in testTag() close and return.
		{
			fclose(data);
			return;
		}
	}
}



struct Contact * getContact(FILE *ptr)
{

	int check,i,j,attrcounter = -1;			//declare/initialize control/flow variables
	int getvalue = 0;			//and buffer variable for reading input
	int checkattributes = 0;
	char *attrvalue;
	char temp = ' ';
	char *buffer;

	char *phn, *frst, *lst;		//declare strings for hard coded attributes

	struct Contact *contact = (struct Contact *)malloc(sizeof(struct Contact));
	if(contact==NULL)
	{
		printf("Error allocating memory\n");
		return NULL;
	}
	struct attribute *attrs = attrAlloc(NULL,25);

	j = 0;

	for(j;j<25;j++)
	{
		do										//find start of tag
		{
			temp = fgetc(ptr);
		}while(temp!='<');

		temp = fgetc(ptr);								//check if closing tag
	
		i = 0;										//reset i and check
		check = 0;
		getvalue = 0;

		buffer = strAlloc(NULL,25);			//allocate buffer

		if(temp!='/') 								//if it's not a closing tag;
		{	
			*(buffer+i) = temp;						//put first character in buffer (since it's part of the tag name)
	
			for(i=1;i<25;i++)						//character limit is 25 I arbitrarily decided
			{
				temp = fgetc(ptr);
				if(temp!='>') *(buffer+i) = temp;
				else
				{
					*(buffer+i) = '\0';				//convert to C-string so I can use strcmp with it
					strAlloc(buffer,i+1);
					check = 1;
					break;
				}		
			}
		
			if(check!=1)						//check for character limit error
			{
				printf("Parsing Error. Tag name limit 24 characters\n");		
				return NULL;
			}
			else
			{
				if(strcmp(buffer,"lastname")==0)
				{
					checkattributes = 1;
					getvalue = 2;
				}
				else if(strcmp(buffer,"firstname")==0)
				{
					checkattributes = 2;
					getvalue = 2;
				}
				else if(strcmp(buffer,"phone")==0)
				{
					checkattributes = 3;
					getvalue = 2;
				}
				else
				{
					getvalue = 1;
					attrcounter++;
				}
	
				push(buffer);				//push tag onto stack;
			}
		}
		else							//if it's a closing tag
		{
			i =0;
			for(i;i<25;i++)
			{
				temp = fgetc(ptr);
				if(temp!='>') *(buffer+i) = temp;
				else
				{
					*(buffer+i) = '\0';
					strAlloc(buffer,i+1);
					check = 1;
					break;
				}
			}

			if(check==1)
			{
				if(strcmp(buffer,stack_top())==0 && strcmp(buffer,"contact")!=0)
				{
					if(strcmp(buffer,"lastname")!=0 && strcmp(buffer,"firstname")!=0 && strcmp(buffer,"phone")!=0)
					{
						(attrs+attrcounter)->name = pop();							//if it matches the last opening tag (as it should) pop it off the stack
						(attrs+attrcounter)->value = attrvalue;					//set the values for the attribute
					}
					else pop();

				}
				else if(strcmp(buffer,stack_top())==0 && strcmp(buffer,"contact")==0)
				{
					if(attrcounter==-1)
					{
						free(attrs);
						attrs = NULL;
					}
					else attrAlloc(attrs,attrcounter+1);				//reallocate attrs to however many attributes were actually found
					
					contact = createContact(frst,lst,phn,attrs,(attrcounter+1));		//create new contact with information
																						//should check all memory functions for errors and contact for NULL etc.
					return contact;														//exit function returning new contact pointer (no errors) 
				}	 	
				else											//if it doesn't error and return
				{
					printf("Error. Non-matching tags found.\n");
					return 0;
				}
			}
		}
		if(getvalue==1)
		{
			attrvalue = freadstring(26,ptr);
		}
		else if(getvalue==2)
		{
			if(checkattributes==1)
				lst = freadstring(26,ptr);		//and here

			if(checkattributes==2)
				frst = freadstring(26,ptr);

			if(checkattributes==3)
				phn = freadstring(20,ptr);

		}		
	}

}







int testTag(FILE *ptr)
{
	int check,i=0;
	char temp = ' ';
	char *buffer = strAlloc(NULL,25);	//allocate buffer

	do										//find start of tag
	{
		temp = fgetc(ptr);
	}while(temp!='<');
	
	for(i=0;i<25;i++)						//character limit is 25 I arbitrarily decided
	{
		temp = fgetc(ptr);
		if(temp!='>') *(buffer+i) = temp;
		else
		{
			*(buffer+i) = '\0';				//convert to C-string so I can use strcmp with it
			strAlloc(buffer,i+1);
			check = 1;
			break;
		}		
	}
	
	if(check!=1)						//check for character limit error
	{
		printf("Parsing Error. Tag name limit 24 characters\n");		
		return -1;
	}
	else if(strcmp(buffer,"contact")==0)
	{
		push(buffer);				//push tag onto stack;
		return 1;
	}
	else if(strcmp(buffer,"/contacts")==0) return 0;
	else
	{
		printf("Parsing Error. Unexpected tag.\n");
		return -1;
	}
}




int testRoot(FILE *ptr)
{
	char temp = ' ';
	char roots[9];

	do										//find start of first tag
	{
		temp = fgetc(ptr);
	}while(temp!='<');

	fgets(roots,9,ptr);
	
	if(strcmp(roots,"contacts")!=0)				//if it doesn't equal contacts then error
	{
		printf("Invalid formatting. Root element must be \"contacts\"\n");
		return 0;
	}
	else push(roots);

	return 1;
}







void printContact(struct Contact *temp, FILE *ptr)
{
	int i=0;
	fprintf(ptr,"\t<contact>\n");
	fprintf(ptr,"\t\t<lastname>%s</lastname>\n",temp->last);
	fprintf(ptr,"\t\t<firstname>%s</firstname>\n",temp->first);
	fprintf(ptr,"\t\t<phone>%s</phone>\n",temp->phone);
	for(i;i<temp->attrsize;i++)								//print out custom attributes if any
	{
		fprintf(ptr,"\t\t<%s>%s</%s>\n",(temp->list+i)->name,(temp->list+i)->value,(temp->list+i)->name);
	}
	fprintf(ptr,"\t</contact>\n");

	return;
}



int saveContacts()
{
	struct Contact *temp = editHead(NULL,4);
	char filename[30];

	printf("Enter the name a file to save to:");
	scanf("%s",filename);

	FILE *save = fopen(filename,"w");

	if(save==NULL)
	{
		printf("Error opening/creating file.\n");
		return 0;
	}

	fprintf(save,"<contacts>\n");
	
	while(temp!=NULL)
	{
		printContact(temp,save);
		
		if(temp->next!=NULL) temp = temp->next;
		else break;
	}

	fprintf(save,"</contacts>\n");
	fclose(save);

	printf("Contacts saved successfully.\n");

	return 0;
}


















