//Written by Robert Winkler
//www.robertwinkler.com

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Contact.h"

#ifndef FUNCTIONS_H
#define FUNCTIONS_H


void Contacts(int flag,struct Contact *temp);

char * readstring(int length, int numbers);		//length counting from 0 so readstring(25, string) would make a string 0-24 (and 24 would be '\0')

char * freadstring(int length, FILE *stream);

struct Contact * newContact();

struct Contact * createContact(char *frst, char *lst, char *phn, struct attribute *data, int num);

void searchContacts();

struct Contact * editHead(struct Contact *ptr, int x);

void insertContact(struct Contact * newcontact);

void displayContact(struct Contact *contact);

void displayContacts();			//loops through displaying the linked list data

int removeContact();

char * strAlloc(char *str, int size);

void freeContact(struct Contact *ptr);

void freeAttributes(struct attribute *ptr);

struct attribute * attrAlloc(struct attribute *attr,int size);







#endif
