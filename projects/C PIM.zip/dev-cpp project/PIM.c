//Written by Robert Winkler
//www.robertwinkler.com

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Contact.h"
#include "myxml.h"
#include "functions.h"

#define CLEAR do{b=getchar();}while(b!='\n');

void printmenu();

int main()
{
	
	char tempfirst[40];						//declare variables to read in new info
	char templast[40];
	int tempphone[20];
	
	struct Contact * temp = NULL;

	char choice = ' ';
	char b;
	int x;
	int save = 0;

	printmenu();

	do
	{
		printf("What action would you like to perform?\n");		

		do																//clean user input
		{
			choice = getchar();
		}while(choice=='\n' || choice==' ' || choice=='\t');
		
		CLEAR
		
		switch(choice)
		{
			case 'A':
			case 'a':
				Contacts(0,NULL);
				save = 1;
				break;

			case 'D':
			case 'd':
				Contacts(3,NULL);
				break;
			
			case 'V':
			case 'v':
				saveContacts();
				save = 0;
				break;

			case 'L':
			case 'l':
				loadContacts();
				break;
			
			case 'R':
			case 'r':
				Contacts(1,NULL);
				save = 1;
				break;

			case 'S':
			case 's':
				Contacts(2,NULL);
				break;

			case 'Q':
			case 'q':
				if(save==1)
				{
					printf("You have unsaved changes to your contacts.  Quit without saving? (Y/N):");
				
					//printf("%c\n",choice);
					//printf("WTF is going on!\n");
					while(1)																//clean user input
					{
						//printf("%c\n",choice);
						choice = getchar();
						if(choice!='Y' && choice!='y' && choice!='N' && choice!='n' && choice!='\n')
							printf("Invalid choice. Try again:");
						else if(choice!='\n') break;
					}
					
					if(choice=='n' || choice =='N')
					{
						saveContacts();
						printf("Contacts saved. Exiting\n");
					}
					choice = 'q';
				}

				break;

			case '?':
				printmenu();
				break;

			default:
				printf("That is not a valid choice\n");

		}

	}while(choice!='q' && choice!='Q');












	return 0;
}



void printmenu()								//print menu
{
	printf("Choice\t\t Action\n");
    printf("------\t\t ------\n");
    printf("A\t\t Add Contact\n");
    printf("D\t\t Display Contact List\n");
    printf("V\t\t Save Contacts\n");
	printf("L\t\t Load Contacts\n");
    printf("R\t\t Remove Contact\n");
    printf("S\t\t Search Contacts\n");
    printf("Q\t\t Quit\n");
    printf("? \t\t Display Help\n\n");

	return;
}
