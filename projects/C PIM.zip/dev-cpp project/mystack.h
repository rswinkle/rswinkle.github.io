//Written by Robert Winkler
//www.robertwinkler.com

#ifndef MYSTACK_H
#define MYSTACK_H


char * pop();

int stack_size();

void push(char *next);

char * stack_top();

void display_stack();
int stack_empty();

void stack_init();




#endif
