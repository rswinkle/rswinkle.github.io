//Written by Robert Winkler
//www.robertwinkler.com

#ifndef CONTACT_H
#define CONTACT_H

struct Contact
{
	char *first;
	char *last;
	char *phone;
	int attrsize;
	struct attribute *list;
	struct Contact *next;
	struct Contact *previous;
};


struct attribute
{
	char *name;
	char *value;
};






#endif
