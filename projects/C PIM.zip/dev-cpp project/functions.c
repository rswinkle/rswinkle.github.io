//Written by Robert Winkler
//www.robertwinkler.com

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Contact.h"
#include "functions.h"


void Contacts(int flag, struct Contact *temp)
{
	static int size = 0;

	char b;	

	if(flag==0)					//add new contact
	{
		if(temp==NULL) temp = newContact();		//read in data and create new contact if necessary

		if(size==0)								//if it's the first contact
		{
			editHead(temp,0);
			size = 1;							//size obviously = 1
		}
		else									//if it's the 2nd or more
		{
			insertContact(temp);
			size++;								//add one to size
		}
	}
	else if(flag==1)
	{
		if(removeContact()) size--;
	}
	else if(flag==2)
	{
		searchContacts();
	}
	else if(flag==3)
	{
		displayContacts();
	}

	return;
}

	
void searchContacts()
{
	char *name;

	int x = 0;

	printf("Enter the last name of the Contact you wish to find:");
	name = readstring(26,0);

	struct Contact *temp = editHead(NULL,4);
	if(temp==NULL)
	{
		printf("The list is empty.\n");
		return;
	}

	if(strcmp(temp->last,name)==0)
	{
		printf("Contact found:\n");		
		displayContact(temp);
		x = 1;
	}
	else
	{	
		while(temp->next!=NULL)
		{
			temp = temp->next;
			if(strcmp(temp->last,name)==0)
			{
				printf("Contact found:\n");
				displayContact(temp);
				x = 1;
				break;
			}
		}
	}

	if(x==0) printf("Contact not found.\n");

	return;
}



struct Contact * newContact()
{
	struct Contact *newcontact = (struct Contact *)malloc(sizeof(struct Contact));			//allocate memory for data
	if(newcontact==NULL)
	{
		printf("Error allocating memory\n");
		return NULL;
	}
	struct attribute *attr = attrAlloc(NULL,25);

	char temp = ' ';
	char choice = ' ';
	char check = ' ';	
	char tempbuffer[25];
	int tempnum[25];
	int i=0;	

	printf("Please enter a Contact to add:\n");				
	printf("Please enter the last name:\n");
	newcontact->last = readstring(26, 0);					//have to do strcpy thing which I still don't understand
															//maybe I can do newcontact->last = &(readstring(26,0);
	printf("Please enter the first name:\n");
	newcontact->first = readstring(26, 0);

	printf("Please enter the phone number (no dashes or spaces):\n");
	newcontact->phone = readstring(21,1);
	

	do
	{
		printf("Would you like to enter another attribute? (Y/N)");
		
		choice = getchar();
		
		do{temp=getchar();}while(temp!='\n');
		
		if(choice=='y' || choice=='Y' && i<25)		//25 is max number of custom attributes
		{
			printf("Enter the attribute name:\n");
			(attr+i)->name = readstring(26,0);

			printf("Enter the attribute value:\n");
			(attr+i)->value = readstring(26,1);

			i++;									//increment i keeping track of number of attributes
		}
	}while(choice=='y' || choice=='Y' && i<25);

	if(i==0)
	{
		free(attr);
		attr = NULL;
	}
	else attrAlloc(attr,i);   		//reallocate to number of attributes stored

	newcontact->list = attr;			//assign it to the Contact
	newcontact->attrsize = i;			//set size (number of custom attributes)

	return newcontact;
}


struct Contact * createContact(char *frst, char *lst, char *phn, struct attribute *data, int num)		//function to create contact from existing data (ie save file)
{
	struct Contact *newcontact = (struct Contact *)malloc(sizeof(struct Contact));
	if(newcontact==NULL)
	{
		printf("Error allocating memory\n");
		return NULL;
	}
	newcontact->first = frst;
	newcontact->last = lst;
	newcontact->phone = phn;

	newcontact->list = data;
	newcontact->attrsize = num;

	return newcontact;
}



char * freadstring(int length, FILE *stream)		//readstring from a file (stupid C doesn't support function overloading)
{
	char *temp = strAlloc(NULL,length);
	char a;
	int i = 0;

	for(i;;i++)
	{
		a = fgetc(stream);

		if(i<length-1 && a!='<')
		{
			*(temp+i) = a;
		}
		else if(i<length-1 && a=='<')
		{
			*(temp+i) = '\0';
			strAlloc(temp,i+1);

			fseek(stream,-1,SEEK_CUR);			//set the file pointer back one (so the '<' is still ahead because calling function needs it)
			return temp;
		}
		else
		{
			printf("Error. Character limit %d.\n",length-1);
			free(temp);
			return NULL;
		}
	}
}





char * readstring(int length, int numbers)		//length counting from 0 so readstring(25, string) would make a string 0-24 (and 24 would be '\0')
{												//parameter numbers tells whether to allow numbers in string or not (0 means no numbers, anything else allows them)
	char *temp = strAlloc(NULL,length);
	char a,b;
	int i, control = 0;

	do
	{
		if(control==2) { do{b=getchar();}while(b!='\n'); }	//clear the input buffer if necessary

		control = 0;		//reset control
		i = 0;				//and loop counter	

		temp = fgets(temp,length,stdin);			//remember what fgets does

		if(temp==NULL)
		{
			printf("fgets error\n");
			control=1;
		}
		for(i;;i++)
		{
			if(i<length-1)
				a = *(temp+i);
			else
			{
				printf("Too many characters entered.  Please re-enter: ");
				control=2;
				break;
			}		
			
			if(!numbers)
			{
				if(a=='1' || a=='2' || a=='3' || a=='4' || a=='5' || a=='6' || a=='7' || a=='8' || a=='9' || a=='0')
				{
					printf("Invalid characters.  Please re-enter: ");
					control=1;
					break;
				}
			}

			if(a=='`' || a=='~' || a=='!' || a=='@' || a=='#' || a=='$' || a=='%' || a=='^' || a=='&' || a=='*' || a=='(' || a==')' || a=='-' || a=='_' || a=='+'
				|| a=='=' || a=='{' || a=='}' || a=='[' || a==']')
			{
				printf("Invalid characters.  Please re-enter: ");
				control=1;
				break;
			}


			if(a=='\n')		//find end of string replace newline with \0 and reallocate
			{
				*(temp+i) = '\0';
				strAlloc(temp,i+1);
				break;
			}
		}

	}while(control!=0);

	return temp;
}
	

struct Contact * editHead(struct Contact *ptr, int x)
{
	static struct Contact *head = NULL;

	if(x==0)
	{
		head = ptr;					//insert first element in the list
		head->next = NULL;
		head->previous = NULL;
	}
	else if(x==1)							//insert a new element at the head of the list and point head at the new first
	{
		struct Contact *temp = head;
		head = ptr;
		head->next = temp;
		temp->previous = head;
	}
	else if(x==2)							//insert a new element right after head
	{
		head->next = ptr;
	}
	else if(ptr==NULL && x==3)				//delete the first element and point head at the new first
	{
		struct Contact *temp = head;
		head = head->next;
		if(head!=NULL) head->previous = NULL;
		freeContact(temp);
	}
	else if(x==4) return head;


	return NULL;	
}

void insertContact(struct Contact * newcontact)
{
	struct Contact *tempHead = editHead(NULL,4);

	int x = 0;

	if(strcmp(newcontact->last,tempHead->last)<=0)		//last name comes before or = head's
	{
		editHead(newcontact,1);				//set head to point at temp
		x = 1;
	}	
	else if(tempHead->next==NULL)			//if there is only 1 in list
	{
		newcontact->next = NULL;
		newcontact->previous = tempHead;
		
		editHead(newcontact,2);			//modify head->next to point at it
		x = 1;
	}		
	else									//there are at least 2 in the list  (yes I know there is a bit of redundancy)					
	{
		struct Contact *iter = tempHead;	

		while(iter->next!=NULL)
		{
			if(strcmp(newcontact->last,iter->last)>=0 && strcmp(newcontact->last,iter->next->last)<=0)
			{
				newcontact->next = iter->next;			//insert temp between iter and iter->next
				newcontact->previous = iter;

				iter->next->previous = newcontact;		//modify iter and iter->next to point at temp

				if(iter==tempHead) editHead(newcontact,2);		//check if iter is still pointing at head (that slight redundancy)
				else iter->next = newcontact;
		
				x = 1;				
				break;
			}
			iter = iter->next;			
		}
		if(x==0)				//insert at the end if it goes there
		{
			iter->next = newcontact;
			newcontact->previous = iter;
			newcontact->next = NULL;
		}
	}

	return;
}


void displayContact(struct Contact *ptr)
{
	int i = 0;

	printf("\nLast Name: %s\n",ptr->last);
	printf("First Name: %s\n",ptr->first);
	printf("Phone Number: %s\n",ptr->phone);

	for(i;i<(ptr->attrsize);i++)
	{
		printf("%s: %s\n",(ptr->list+i)->name,(ptr->list+i)->value);
	}	

	return;
}



void displayContacts()			//loops through displaying the linked list data
{
	struct Contact *temp = editHead(NULL,4);	

	if(temp!=NULL)
	{
		while(1)
		{
			displayContact(temp);
			if(temp->next==NULL)
			{
				printf("\n"); 
				break;
			}			
			temp = temp->next;
		}
	}
	else printf("The list is empty\n");			//if size 0

	return;
}


int removeContact()
{

	char *name;
	int x = 0;

	printf("Enter the last name of the Contact you wish to remove:");
	name = readstring(26,0);

	struct Contact *temphead = editHead(NULL,4);
	if(temphead==NULL)
	{
		printf("The list is empty.\n");
		return 0;
	}

	if(strcmp(temphead->last,name)==0)		//if head matches
	{
		editHead(NULL,3);
		x = 1;
	}		
	else
	{
		struct Contact *temp = temphead;

		while(temp->next!=NULL)						//loop through checking
		{
			if(strcmp(temp->last,name)==0)			//if it matches remove element
			{
				temp->previous->next = temp->next;				//I know this is weird but I understand it and it works
				temp->next->previous = temp->previous;			
																
				freeContact(temp);

				x = 1;
				break;
			}
			temp = temp->next;
		}
		
		if(x==0)			//if still haven't found it check last element
		{
			if(strcmp(temp->last,name)==0)
			{
				temp->previous->next = NULL;					//same issue here with head? or editHead((NULL,2)
				freeContact(temp);
				x = 1;
			}
		}
	}

	if(x==0)
	{
		printf("Contact not found.\n");
		return 0;
	}
	else
	{
		printf("Contact removed.\n");
		return 1;
	}
}


void freeContact(struct Contact *ptr)
{
	int i = 0;

	free(ptr->first);
	free(ptr->last);
	free(ptr->phone);

	for(i;i<ptr->attrsize;i++)
		freeAttributes(ptr->list+i);
	
	free(ptr->list);
	free(ptr);

}

void freeAttributes(struct attribute *ptr)
{
	free(ptr->name);
	free(ptr->value);
}




struct attribute * attrAlloc(struct attribute *attr,int size)
{
	attr = (struct attribute *)realloc(attr,sizeof(struct attribute)*size);

	if(attr==NULL)
	{
		printf("Error allocating memory.\n");
		return attr;
	}
	
	return attr;
}






char * strAlloc(char *str,int size)
{
	str = (char *)realloc(str,sizeof(char)*size);

	if(str==NULL)
	{
		printf("Error Allocating memory\n");
		return str;
	}

	return str;
}

	






