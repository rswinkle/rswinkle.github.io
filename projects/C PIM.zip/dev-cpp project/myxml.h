//Written by Robert Winkler
//www.robertwinkler.com

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Contact.h"

#ifndef MYXML_H
#define MYXML_H


void printContact(struct Contact *temp, FILE *ptr);



int saveContacts();




void loadContacts();

int testRoot(FILE *ptr);

int testTag(FILE *ptr);

struct Contact * getContact(FILE *ptr);




#endif


