Written by Robert Winkler
10/24/09


***********README***********


Contents:
gopher.cpp
gopher2.cpp
gopher
gopher2
gopher.exe
gopher2.exe
GopherAndHawks_in.txt
GopherAndHawks_in_original.txt
GopherAndHawks_key.txt
GopherAndHawks_out.txt
2009_ProblemSet.pdf
README.txt




So this folder contains 2 different programs gopher and gopher2 in both linux binary and exe format along with the source for both.

Both are based on the Gopher and Hawks problem from the Women in Computer Science (WCS) 2009 programming competition at ASU.  The 2009 problem
set (with this problem), the test input (GopherAndHawks_in_original.txt), and the correct output (GopherAndHawks_key.txt) are included
in this folder.  These are taken from the WCS website http://www.eas.asu.edu/~wcs/competition/ where you can also find test cases for the rest
of the problems


	gopher
==============
gopher takes input from GopherAndHawks_in.txt and outputs the solution (as defined in the WCS problem) in GopherAndHawks_out.txt.
Notice that I changed the input slightly from the problem.  I included a number telling me how many points were in the problem
(besides the starting and target points).  I was and am more interested in the algorithm than reading input and it made it much simpler.
Again the original problem input (for the test case) is in GopherAndHawks_in_original.txt

Also gopher can take 1 integer argument.  If the argument is 1 it outputs the pointtree data structure to the screen/console at the end of each case.
If the argument is 2, it outputs the pointtree data structure after every itteration of the main loop (or in other words after increase in the size of the
pointtree) and the final size of course.  If the argument is 0 then it will only output the solution to GopherAndHawks_out.txt  Likewise if no argument
is passed or an argument other than 1 or 2. 

So for the following input (assuming this is all you had in GopherAndHawks_in.txt):
1 1
0 0
120 120
9
60 0
0 60
60 60
0 120
0 180
60 180
120 180
60 120
120 60

0 0


And you ran (linux:) ./gopher 1 or (windows:) gopher.exe 1(assuming it's in your current directory) the following would be output to the console:

Case Number: 1
==================
level 0: (0,0)
level 1: (60,0)(0,60)
level 2: (60,60)(0,120)
level 3: (60,120)(120,60)(0,180)

If you ran (linux:) ./gopher 2 or (windows:) gopher.exe 2the output to the console would be:

Case Number: 1
==================
level 0: (0,0)
level 1: (60,0)(0,60)
==================
level 0: (0,0)
level 1: (60,0)(0,60)
level 2: (60,60)(0,120)
==================
level 0: (0,0)
level 1: (60,0)(0,60)
level 2: (60,60)(0,120)
level 3: (60,120)(120,60)(0,180)

and in both cases the contents of GopherAndHawks_out.txt would be:
Yes, visiting 3 other holes.

Please note that if the last level is empty that is not a bug.  It just measn that no new points were reached from the previous level (and obviously not the target hole either).  The output to the file for such cases would of course be "No."


	gopher2
===============
This version has a few differences from gopher.  It takes doubles for the gopher speed and minutes values in the tests (first line of each test).
It's the exact same functionality of course but I thought it'd be nice to be able to test non-integer distances.

In addition gopher 2 can take 3 arguments.  The first one is the same as the argument for gopher (1 or 2 to display the tree information or 0 not to).
The second one is a user specified input file.  Obviously it must exist and contain your test cases in order for the program to do anything.
If your specified program doesn't exist the program will exit.  The 3rd argument is the output file.  In most cases if it doesn't exist it
will be created but it depends on your operating system and user/directory permissions etc.

All 3 arguments are optional but they must be in that order if given.  You can have just the display tree argument, just the display tree and the input file,
or all 3.  If you want to specify the input or both files but don't want to the tree output to the console just pass 0 for the first argument.  If any file
is not passed as a parameter, gopher2 will open the corresponding file (or both) name in gopher (GopherAndHawks_in.txt and GopherAndHawks_out.txt).



















