//Written by Robert Winkler
//Solves Gopher and Hawks problem* from
//the ASU WCS 2009 programming competition
//
//
//*To make it easier on myself (and because I'm more interested in making the algorithm than reading input)
//I added a line to each test case (after the start and target holes) that has the number of points for that
//test case.


#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include <cstdlib>








using namespace std;








class point				//define point class
{
	public:
	
	double x, y;
	
	int used;
	
	point(double a, double b)
	{
		x = a;
		y = b;
		
		used = 0;
	}
};


class pointtree			//define point tree data structure
{
	public:
	
	int currentlevel, size;
	
	vector<vector<point> > reach;
	
	pointtree(point a)							//constructor (point a is the starting hole)
	{
		reach.push_back(vector<point>());
		currentlevel = 0;
		size = 0;
		reach[currentlevel].push_back(a);
	}
	
	void nextlevel(int gopherdist, vector<point> & pointlist)		//check which points (if any) can be reached from points on previous level
	{																//and place them on current level (each level is a vector)
		reach.push_back(vector<point>());	
		currentlevel++;	
		
		for(int i=0;i<reach[currentlevel-1].size();i++)
		{
			for(int j=0;j<pointlist.size();j++)
			{
				if((pointlist[j].used==0) && (checkdistance(reach[currentlevel-1][i],pointlist[j])<=gopherdist))
				{
					reach[currentlevel].push_back(pointlist[j]);
					pointlist[j].used = 1;
					this->size++;
				}
			}
		}
	}
	

	void printtree()						//print tree to see levels (was useful for debugging and is just cool to watch)
	{
		for(int j=0;j<reach.size();j++)
		{
			cout<<"level "<<j<<": ";
			for(int k=0;k<reach[j].size();k++)
			{
				cout<<"("<<reach[j][k].x<<","<<reach[j][k].y<<")";
			}
			cout<<endl;
		}
		return;
	}		
		
	
	
	double checkdistance(point a, point b)					//return distance between 2 points
	{
		double distance = sqrt(pow((a.x-b.x),2)+pow((a.y-b.y),2));
		return distance;
	}
	
	int reachedpoint(int gopherdist, point a)				//check if you can reach point a from any point on current level
	{
		for(int i=0;i<reach[currentlevel].size();i++)
		{
			if(checkdistance(reach[currentlevel][i],a)<=gopherdist) return 1;
		}
		
		return 0;
	}
	
};
	





int main(int argc, char *argv[])
{
	ifstream fin;
	ofstream fout;
	
	fin.open("GopherAndHawks_in.txt");
	fout.open("GopherAndHawks_out.txt");
	
	int gopherspeed,minutes,reachcheck, gopherdistance, numpoints,oldsize,newsize, argument, casenumber;
	char a;
	double startx,starty,targetx,targety,tempx,tempy;
	
	vector<point> points;
	
	vector<double> x;
	vector<double> y;
	
	casenumber = 0;			//initialize to 0.  casenumber keeps track of the testcase


	if(argc!=1)
	{
		argument = atoi(argv[1]);
		if(argument!=1 && argument!=2 && argument!=0) cout<<"Invalid argument"<<endl;
	}
	else argument = 0;

	while(!fin.eof())
	{
		reachcheck = 0;		//reset/clear variables
		points.clear();
		x.clear();
		y.clear();

		fin>>gopherspeed>>minutes;							//read in  values
		if(gopherspeed==0 && minutes==0) break;				//if end break out of loop


		casenumber++;							//increment casenumber

		fin>>startx>>starty>>targetx>>targety;

		point start(startx,starty);					//create start and target points
		point target(targetx,targety);

		pointtree path(start);						//create pointtree

		fin>>numpoints;
	

		for(int i=0;i<numpoints;i++)		//read in points
		{	
			fin>>tempx>>tempy;
			x.push_back(tempx);
			y.push_back(tempy);
		}
		

		for(int i=0;i<x.size();i++)				//load points into points vector (calling point constructor every time of course)
		{
			points.push_back(point(x[i],y[i]));	
		}
		
		
		gopherdistance = gopherspeed*minutes*60;
		
		
		oldsize = 0;			//variable used to breakout of loop if no new points were reached

		if(argument!=0)
		{
			cout<<"Case Number: "<<casenumber<<endl;
			cout<<"=================="<<endl;
		}

		if(path.reachedpoint(gopherdistance,target)) reachcheck=1;	//if you can reach target from starting hole
		else
		{
			for(int i=0;;i++)
			{

				path.nextlevel(gopherdistance, points);				//create next level of path pointtree
			
				if(oldsize==path.size) break;						//if no new points reached break


				if(path.reachedpoint(gopherdistance,target)) 		//if you can reach target from new level break
				{
					reachcheck = 1;
					break;
				}

				if(path.size==points.size()) break;				//if all points are in tree and you still didn't reach target in the previous step break
				
				if(argument==2)								//output tree growth if user requests it (p
				{
					path.printtree();
					cout<<"=================="<<endl;			
				}
				
				oldsize = path.size;						//set oldsize for next loop iteration
			}
		}
		
		if(argument!=0)
		{
			path.printtree();
			cout<<endl;			
		}


		if(reachcheck == 1)														//output appropriate results
			fout<<"Yes, visiting "<<path.currentlevel<<" other holes."<<endl;
		else
			fout<<"No."<<endl;

	
	}
	
	
	fin.close();		//close file streams
	fout.close();
	

	
	
	
	return 0;	
}
